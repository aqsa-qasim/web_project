<?php
// Connection file
require_once 'connection.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $msg = $_POST['message'];

    // Insert message into the database
    $query = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$msg')";
    if (mysqli_query($con, $query)) {
        $message = 'Thank you for contacting us! We will get back to you soon.';
    } else {
        $message = 'Error submitting your message. Please try again later.';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/contact_us.css" />
    <link rel="stylesheet" href="css/footer.css" />
</head>
<body>
<div>

   <center> <h2>Contact Us</h2></center>
    <form method="POST">
        <label>Your Name:</label>
        <input type="text" name="name" required /><br/><br/>

        <label>Your Email:</label>
        <input type="email" name="email" required /><br/><br/>

        <label>Your Message:</label>
        <textarea name="message" rows="5" required></textarea><br/><br/>

        <center><input type="submit" value="Send Message" /></center>
    </form>
    <p style="color: white;"><?php echo $message; ?></p>
    <br><br> <br><br><br><br>
    <?php 
             require 'footer.php';// Include the footer 
            ?>
</div>
</body>
</html>
