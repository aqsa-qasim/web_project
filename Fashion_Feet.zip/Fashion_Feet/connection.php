<?php
// Database connection parameters for localhost
$host = "localhost";
$username = "root";
$password = "";
$database = "fashion_feet";

// Establishing the database connection
$con = mysqli_connect($host, $username, $password, $database);

// Checking the connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
