<!-- footer.php -->
<link rel="stylesheet" href="css/footer.css">
<footer class="footer">
    <div class="container">
        <p>Copyright &copy . All Rights Reserved. | Contact Us: 0000 00000</p>
        <p>This website is developed by </p>
    </div>
</footer>
