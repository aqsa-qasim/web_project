<?php
session_start();

// If already logged in, redirect to panel
if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: admin_panel.php');
    exit;
}

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Hard-coded admin credentials (for demonstration purposes)
    if($username === 'admin' && $password === 'admin'){
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin_panel.php');
        exit;
    } else {
        $error = "Invalid credentials. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="css/admin_login.css">
</head>
<body>
    <h2>WELCOME BACK!</h2>
    <form method="POST">
        <label>Username:</label>
        <input type="text" name="username" required /><br/><br/>
        <label>Password:</label>
        <input type="password" name="password" required /><br/><br/>
        <input type="submit" value="Login" />
    </form>
    <p style="color: red;"><?php echo $error;?></p>
</body>
</html>
