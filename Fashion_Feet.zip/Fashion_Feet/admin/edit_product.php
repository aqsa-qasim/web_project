<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Connection file
require_once '../connection.php';

$message = '';
$product = null;

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch the product details
    $query = "SELECT * FROM items WHERE id = $product_id";
    $result = mysqli_query($con, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        header('Location: admin_panel.php?error=Product not found');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $product_id = $_POST['id'];

    // Update product details
    $update_query = "UPDATE items SET name = '$name', price = '$price' WHERE id = $product_id";
    if (mysqli_query($con, $update_query)) {
        $message = 'Product updated successfully.';
    } else {
        $message = 'Error updating product: ' . mysqli_error($con);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/edit_product.css" />
</head>
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
</style>
<body>
    <center><h2>Edit Product</h2></center>
    <p><a href="admin_panel.php">Back to Admin Panel</a></p>

    <?php if ($product): ?>
    <form method="POST">
        <input type="hidden" name="id" value="<?php echo $product['id']; ?>" />

        <label>Product Name:</label>
        <input type="text" name="name" value="<?php echo $product['name']; ?>" required /><br/><br/>

        <label>Price:</label>
        <input type="number" name="price" value="<?php echo $product['price']; ?>" required /><br/><br/>

        <center> <input type="submit" value="Update Product" style="background-color: black;" /></center>
    </form>
    <?php endif; ?>

    <p style="color: green;"><?php echo $message; ?></p>
</body>
</html>
