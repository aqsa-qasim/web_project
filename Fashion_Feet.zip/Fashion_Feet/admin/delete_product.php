<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Connection file
require_once '../connection.php';

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch the product image path for deletion
    $query = "SELECT image FROM items WHERE id = $product_id";
    $result = mysqli_query($con, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
        $image_path = "../" . $product['image'];

        // Delete product from the database
        $delete_query = "DELETE FROM items WHERE id = $product_id";
        if (mysqli_query($con, $delete_query)) {
            // Delete image file
            if (file_exists($image_path)) {
                unlink($image_path);
            }
            header('Location: admin_panel.php?message=Product deleted successfully');
        } else {
            header('Location: admin_panel.php?error=Error deleting product');
        }
    } else {
        header('Location: admin_panel.php?error=Product not found');
    }
} else {
    header('Location: admin_panel.php?error=Invalid request');
}
?>
