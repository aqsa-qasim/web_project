<?php
session_start();
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: admin_login.php');
    exit;
}
//Connection file 
require_once '../connection.php';

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // Sanitize inputs
    $name  = $_POST['name'];
    $price = $_POST['price'];

    // Check for file upload without error
    if(isset($_FILES['image']) && $_FILES['image']['error'] === 0){
        $allowed_ext = array('jpg','jpeg','png','gif');
        $file_tmp    = $_FILES['image']['tmp_name'];
        $file_name   = $_FILES['image']['name'];
        $ext         = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if(in_array($ext, $allowed_ext)){
            // Create a unique filename for the image
            $new_filename = uniqid('', true) . "." . $ext;
            // Upload path relative to the project root
            $upload_path = "../img/" . $new_filename;

            // Move file to the designated folder
            if(move_uploaded_file($file_tmp, $upload_path)){
                // Store relative path in database
                $image_path = "img/" . $new_filename;
                $insert_query = "INSERT INTO items (name, price, image) VALUES ('$name', '$price', '$image_path')";
                if(mysqli_query($con, $insert_query)){
                    $message = "Product added successfully!";
                } else {
                    $message = "Error adding product: " . mysqli_error($con);
                }
            } else {
                $message = "Failed to upload image.";
            }
        } else {
            $message = "Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.";
        }
    } else {
        $message = "Image upload error.";
    }
}

// Fetch all products to display in the admin panel
$products_query = "SELECT * FROM items";
$products_result = mysqli_query($con, $products_query) or die(mysqli_error($con));
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/admin_panel.css" />
    
</head>
<body>
    <header>
    <h1 class="heading">FASHION FEET</h1>
    </header>
    <h2>Admin Panel</h2>
    <h3>Add New Product</h3>
    <form method="POST" enctype="multipart/form-data">
        <label>Product Name:</label>
        <input type="text" name="name" required /><br/><br/>
        
        <label>Price:</label>
        <input type="number" name="price" required /><br/><br/>
        
        <label>Product Image:</label>
        <input type="file" name="image" accept="image/*" required /><br/><br/>
        
        <input type="submit" value="Add Product"  style="background-color: black;" />
    </form>
    <p style="color: green;"><?php echo $message;?></p>
    
    <h3>Existing Products</h3>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th><th>Name</th><th>Price</th><th>Image</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($products_result)) { ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo ($row['name']);?></td>
            <td><?php echo ($row['price']);?></td>
            <td>
                <img src="../<?php echo ($row['image']); ?>" 
                     alt="<?php echo ($row['name']); ?>" 
                     style="width:50px;height:auto;"/>
            </td>
            <td>
    <a href="edit_product.php?id=<?php echo $row['id']; ?>">Edit</a> | 
    <a href="delete_product.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
</td>

        </tr>
        <?php } ?>
    </table>
</body>
</html>
