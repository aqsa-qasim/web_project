<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Connection file
require_once '../connection.php';

// Fetch all contact messages from the database
$query = "SELECT * FROM contact_messages ORDER BY submitted_at DESC";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin_contact_messages.css">
    <title>Admin - Contact Messages</title>
</head>
<body>
    <h2>Contact Messages</h2>
    <p><a href="admin_panel.php">Back to Admin Panel</a></p>

    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Message</th><th>Submitted At</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo nl2br($row['message']); ?></td>
            <td><?php echo $row['submitted_at']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
