<?php
session_start();
require 'connection.php';
require 'check_if_added.php'; // Ensure this file exists and functions as expected

// Fetch all products from the database
$product_query = "SELECT * FROM items";
$product_result = mysqli_query($con, $product_query) or die(mysqli_error($con));
?>
<!DOCTYPE html>
<html>
<head>
    <title>Fashion Feet - Products</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- jquery library -->
    <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
    <!-- Latest compiled and minified javascript -->
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <!-- External CSS -->
    <link rel="stylesheet" href="css/product.css" type="text/css">
</head>
<body>
    <div>
        <?php require 'header.php'; ?>
        
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our Fashion Feet Store!</h1>
                <p>We have the best products for you. No need to hunt around, we have all in one place.</p>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <?php
                while($row = mysqli_fetch_assoc($product_result)) {
                    $item_id    = $row['id'];
                    $item_name  = $row['name'];
                    $item_price = $row['price'];
                    $image_path = ($row['image']); // Use image path from DB
                ?>
                <div class="col-md-4 col-sm-6">
                    <div class="thumbnail">
                        <a href="cart.php">
                            <img src="<?php echo $image_path; ?>" alt="<?php echo htmlspecialchars($item_name); ?>">
                        </a>
                        <center>
                            <div class="caption">
                                <h3><?php echo ($item_name); ?></h3>
                                <p>Price: Rs. <?php echo number_format($item_price, 2); ?></p>
                                <?php if(!isset($_SESSION['email'])) { ?>
                                    <p>
                                        <a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a>
                                    </p>
                                <?php } else {
                                    if(check_if_added_to_cart($item_id)) {
                                        echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                                    } else { ?>
                                        <a href="cart_add.php?id=<?php echo $item_id; ?>" class="btn btn-block btn-primary">Add to cart</a>
                                <?php }
                                } ?>
                            </div>
                        </center>
                    </div>
                </div>
                <?php } // End of products loop ?>
            </div>
        </div>
        
        <br><br><br><br>
        <?php 
                require 'footer.php'; // Include the footer
        ?>
    </div>
</body>
</html>
